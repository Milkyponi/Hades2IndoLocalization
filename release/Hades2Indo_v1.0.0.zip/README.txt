================================================================================
     MOD LOKALISASI BAHASA INDONESIA HADES II (VERSI 1.0.0)
     Divisi Game Modding & Lokalisasi - Milky Brain
     Lead Modder & Localizer: Ochi
================================================================================

[DESKRIPSI MOD]
Mod ini menerjemahkan seluruh dialog cerita, narasi, subtitle, ambient barks, 
lirik lagu Scylla, dan celetukan in-game Hades II ke dalam Bahasa Indonesia yang 
hidup, alami, berkarakter, dan peka konteks adegan (anti Google Translate).

[KEBIJAKAN BAHASA (STANDAR RESMI MILKY BRAIN)]
- Subtitle & Dialog: 100% Bahasa Indonesia
- UI, HUD, Menu Opsi & Deskripsi Boon: Tetap 100% English Original 
  (guna menjaga familiaritas gaming dan panduan build internasional)
- Stuttering Synchronized: Kata terbata-bata/gagap sinkron secara fonetik 100% 
  dengan kata yang diucapkan.

[PANDUAN INSTALASI CEPAT - DUAL COMPATIBILITY]
Mod ini mendukung DUAL COMPATIBILITY (Slot EN & Slot Bahasa Indonesia):
- Langsung aktif otomatis di slot default English (tanpa perlu ubah pengaturan).
- Maupun saat memilih 'Bahasa Indonesia' di menu Options -> Language.

1. Cukup ekstrak isi folder zip ini ke direktori Hades II:
   Contoh: .../SteamLibrary/steamapps/common/Hades II/
   (Timpa/replace folder Content).
2. Jalankan game via Steam dan langsung mainkan!
================================================================================
